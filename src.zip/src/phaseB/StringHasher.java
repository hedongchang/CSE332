package phaseB;
import providedCode.Hasher;


public class StringHasher implements Hasher<String> {
	
	@Override
	public int hash(String s) {
		// TODO Auto-generated method stub
		return 0;
	}
}
